import pandas as pd
import mlflow

from pathlib import Path


# ============================================================
# Project paths
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

RESULTS_DIR = PROJECT_ROOT / "results"
RESULTS_PATH = RESULTS_DIR / "v1_model_comparison.csv"


# ============================================================
# MLflow experiment
# ============================================================

EXPERIMENT_NAME = "Flight Delay Prediction"

experiment = mlflow.get_experiment_by_name(EXPERIMENT_NAME)

if experiment is None:
    raise ValueError(
        f"MLflow experiment '{EXPERIMENT_NAME}' was not found."
    )


print(f"Found MLflow experiment: {EXPERIMENT_NAME}")
print(f"Experiment ID: {experiment.experiment_id}")


# ============================================================
# Retrieve successful MLflow runs
# ============================================================

runs = mlflow.search_runs(
    experiment_ids=[experiment.experiment_id],
    filter_string="attributes.status = 'FINISHED'",
    order_by=["start_time DESC"],
)


if runs.empty:
    raise ValueError(
        "No successful MLflow runs were found."
    )


print(f"\nSuccessful MLflow runs found: {len(runs)}")


# ============================================================
# Models to compare
#
# We use the most recent successful run for each model.
# ============================================================

MODEL_RUNS = {
    "Balanced Logistic Regression":
        "Logistic Regression Baseline",

    "Random Forest":
        "Random Forest v1",
}


comparison_rows = []


# ============================================================
# Extract metrics from MLflow
# ============================================================

for model_name, run_name in MODEL_RUNS.items():

    matching_runs = runs[
        runs["tags.mlflow.runName"] == run_name
    ].copy()

    if matching_runs.empty:
        print(
            f"\nWarning: No successful run found for "
            f"'{run_name}'."
        )
        continue

    # search_runs is ordered newest first,
    # so use the most recent successful run.
    run = matching_runs.iloc[0]

    comparison_rows.append(
        {
            "Model": model_name,

            "Run Name":
                run["tags.mlflow.runName"],

            "Run ID":
                run["run_id"],

            "Validation Accuracy":
                run.get(
                    "metrics.validation_accuracy",
                    float("nan"),
                ),

            "Validation Precision":
                run.get(
                    "metrics.validation_precision",
                    float("nan"),
                ),

            "Validation Recall":
                run.get(
                    "metrics.validation_recall",
                    float("nan"),
                ),

            "Validation F1 Score":
                run.get(
                    "metrics.validation_f1",
                    float("nan"),
                ),

            "Validation ROC-AUC":
                run.get(
                    "metrics.validation_roc_auc",
                    float("nan"),
                ),

            "Test Accuracy":
                run.get(
                    "metrics.test_accuracy",
                    float("nan"),
                ),

            "Test Precision":
                run.get(
                    "metrics.test_precision",
                    float("nan"),
                ),

            "Test Recall":
                run.get(
                    "metrics.test_recall",
                    float("nan"),
                ),

            "Test F1 Score":
                run.get(
                    "metrics.test_f1",
                    float("nan"),
                ),

            "Test ROC-AUC":
                run.get(
                    "metrics.test_roc_auc",
                    float("nan"),
                ),
        }
    )


# ============================================================
# Build comparison table
# ============================================================

if not comparison_rows:
    raise ValueError(
        "None of the requested model runs were found."
    )


comparison_df = pd.DataFrame(comparison_rows)


# ============================================================
# Save comparison
# ============================================================

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

comparison_df.to_csv(
    RESULTS_PATH,
    index=False,
)


# ============================================================
# Display results
# ============================================================

print(
    "\n================ MODEL COMPARISON ================"
)

display_columns = [
    "Model",
    "Validation Accuracy",
    "Validation Precision",
    "Validation Recall",
    "Validation F1 Score",
    "Validation ROC-AUC",
    "Test Accuracy",
    "Test Precision",
    "Test Recall",
    "Test F1 Score",
    "Test ROC-AUC",
]

print(
    comparison_df[
        display_columns
    ].round(4).to_string(index=False)
)


print(
    f"\nSaved model comparison table to:\n"
    f"{RESULTS_PATH}"
)


# ============================================================
# Metric interpretation
# ============================================================

print(
    "\n================ METRIC INTERPRETATION ================"
)

print(
    "- Accuracy measures the overall percentage of "
    "correct predictions."
)

print(
    "- Precision measures how often a predicted delay "
    "was actually delayed."
)

print(
    "- Recall measures how many actual delayed flights "
    "the model successfully identified."
)

print(
    "- F1 Score balances precision and recall."
)

print(
    "- ROC-AUC measures the model's ability to rank "
    "delayed flights above non-delayed flights across "
    "classification thresholds."
)

print(
    "- Because delayed flights are the minority class, "
    "accuracy should not be interpreted by itself."
)

print(
    "\nComparison generated from existing MLflow runs. "
    "Models were not retrained."
)