# ============================================================
# EXPERIMENT 1 — Q1 2026 RANDOM FOREST
#
# Question:
# Does training with more historical data improve the model?
#
# Train:      January + February 2026
# Validation: March 1-15, 2026
# Test:       March 16-31, 2026
#
# Same features and Random Forest settings as V1.
# ============================================================

import pandas as pd
from pathlib import Path
import joblib

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder


# ============================================================
# Paths
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

DATA_PATH = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "flights_model_ready_q1_2026.csv"
)

MODEL_DIR = PROJECT_ROOT / "models"
RESULTS_DIR = PROJECT_ROOT / "results"

MODEL_PATH = (
    MODEL_DIR
    / "experiment1_q1_random_forest.joblib"
)

RESULTS_PATH = (
    RESULTS_DIR
    / "experiment1_q1_random_forest_metrics.csv"
)


# ============================================================
# Load data
# ============================================================

print("=" * 65)
print("EXPERIMENT 1 — Q1 2026 RANDOM FOREST")
print("=" * 65)

if not DATA_PATH.exists():
    raise FileNotFoundError(
        f"Dataset not found:\n{DATA_PATH}\n\n"
        "Run data_prep_q1.py first."
    )

print("\nLoading Q1 model-ready dataset...")

df = pd.read_csv(
    DATA_PATH,
    low_memory=False
)

print(f"Dataset shape: {df.shape}")


# ============================================================
# Validate data
# ============================================================

required_columns = [
    "FL_DATE",
    "OP_CARRIER_FL_NUM",
    "ORIGIN",
    "DEST",
    "CRS_DEP_TIME",
    "MONTH",
    "DAY_OF_WEEK",
    "DAY",
    "IS_WEEKEND",
    "CRS_DEP_HOUR",
    "CRS_DEP_MINUTE",
    "ROUTE",
    "TARGET_DELAYED",
]

missing_columns = [
    col for col in required_columns
    if col not in df.columns
]

if missing_columns:
    raise ValueError(
        f"Missing required columns: {missing_columns}"
    )


# ============================================================
# Prepare dates
# ============================================================

df["FL_DATE"] = pd.to_datetime(
    df["FL_DATE"],
    errors="coerce"
)

df = df[
    df["FL_DATE"].notna()
].copy()

df = df.sort_values(
    "FL_DATE"
).reset_index(drop=True)


# ============================================================
# Features
#
# Same 11 features as V1.
# ============================================================

features = [
    "OP_CARRIER_FL_NUM",
    "ORIGIN",
    "DEST",
    "CRS_DEP_TIME",
    "MONTH",
    "DAY_OF_WEEK",
    "DAY",
    "IS_WEEKEND",
    "CRS_DEP_HOUR",
    "CRS_DEP_MINUTE",
    "ROUTE",
]

target = "TARGET_DELAYED"

print("\nUsing features:")

for feature in features:
    print(f"- {feature}")

print(f"\nNumber of features: {len(features)}")


# ============================================================
# Chronological split
# ============================================================

train_df = df[
    df["FL_DATE"] < "2026-03-01"
].copy()

valid_df = df[
    (df["FL_DATE"] >= "2026-03-01")
    & (df["FL_DATE"] <= "2026-03-15")
].copy()

test_df = df[
    df["FL_DATE"] >= "2026-03-16"
].copy()


if train_df.empty:
    raise ValueError("Training dataset is empty.")

if valid_df.empty:
    raise ValueError("Validation dataset is empty.")

if test_df.empty:
    raise ValueError("Test dataset is empty.")


# ============================================================
# X / y
# ============================================================

X_train = train_df[features].copy()
y_train = train_df[target].astype(int).copy()

X_valid = valid_df[features].copy()
y_valid = valid_df[target].astype(int).copy()

X_test = test_df[features].copy()
y_test = test_df[target].astype(int).copy()


# ============================================================
# Split summary
# ============================================================

print("\n" + "=" * 65)
print("DATA SPLIT")
print("=" * 65)

print(f"\nTraining rows:   {len(X_train):,}")
print(f"Validation rows: {len(X_valid):,}")
print(f"Test rows:       {len(X_test):,}")

print(
    "\nTraining dates:   "
    f"{train_df['FL_DATE'].min().date()} through "
    f"{train_df['FL_DATE'].max().date()}"
)

print(
    "Validation dates: "
    f"{valid_df['FL_DATE'].min().date()} through "
    f"{valid_df['FL_DATE'].max().date()}"
)

print(
    "Test dates:       "
    f"{test_df['FL_DATE'].min().date()} through "
    f"{test_df['FL_DATE'].max().date()}"
)


# ============================================================
# Delay rates
# ============================================================

train_delay_rate = y_train.mean()
valid_delay_rate = y_valid.mean()
test_delay_rate = y_test.mean()

print("\nDelay rates:")
print(f"Training:   {train_delay_rate:.2%}")
print(f"Validation: {valid_delay_rate:.2%}")
print(f"Test:       {test_delay_rate:.2%}")


# ============================================================
# Feature types
# ============================================================

numeric_features = (
    X_train
    .select_dtypes(include=["number"])
    .columns
    .tolist()
)

categorical_features = [
    col for col in features
    if col not in numeric_features
]

print("\nNumeric features:")
print(numeric_features)

print("\nCategorical features:")
print(categorical_features)


# ============================================================
# Preprocessing
# ============================================================

numeric_transformer = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(strategy="median")
        )
    ]
)

categorical_transformer = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(
                strategy="most_frequent"
            )
        ),
        (
            "onehot",
            OneHotEncoder(
                handle_unknown="ignore"
            )
        ),
    ]
)

preprocessor = ColumnTransformer(
    transformers=[
        (
            "num",
            numeric_transformer,
            numeric_features
        ),
        (
            "cat",
            categorical_transformer,
            categorical_features
        ),
    ]
)


# ============================================================
# Random Forest
#
# Same settings as January V1.
# ============================================================

model = Pipeline(
    steps=[
        (
            "preprocessor",
            preprocessor
        ),
        (
            "classifier",
            RandomForestClassifier(
                n_estimators=100,
                max_depth=15,
                min_samples_split=10,
                min_samples_leaf=5,
                class_weight="balanced",
                random_state=42,
                n_jobs=-1,
            )
        ),
    ]
)


# ============================================================
# Train
# ============================================================

print("\n" + "=" * 65)
print("TRAINING")
print("=" * 65)

print(
    "\nTraining Experiment 1 Random Forest..."
)

print(
    "This uses January + February, "
    "so it may take several minutes."
)

model.fit(
    X_train,
    y_train
)

print("\nTraining complete.")


# ============================================================
# Evaluation function
# ============================================================

def evaluate_model(model, X, y):

    predictions = model.predict(X)

    probabilities = (
        model.predict_proba(X)[:, 1]
    )

    metrics = {
        "accuracy": accuracy_score(
            y,
            predictions
        ),
        "precision": precision_score(
            y,
            predictions,
            zero_division=0
        ),
        "recall": recall_score(
            y,
            predictions,
            zero_division=0
        ),
        "f1": f1_score(
            y,
            predictions,
            zero_division=0
        ),
        "roc_auc": roc_auc_score(
            y,
            probabilities
        ),
    }

    return predictions, probabilities, metrics


# ============================================================
# Validation
# ============================================================

y_valid_pred, y_valid_prob, valid_metrics = (
    evaluate_model(
        model,
        X_valid,
        y_valid
    )
)

print("\n" + "=" * 65)
print("VALIDATION METRICS")
print("=" * 65)

print(
    f"Accuracy:  "
    f"{valid_metrics['accuracy']:.4f}"
)

print(
    f"Precision: "
    f"{valid_metrics['precision']:.4f}"
)

print(
    f"Recall:    "
    f"{valid_metrics['recall']:.4f}"
)

print(
    f"F1 Score:  "
    f"{valid_metrics['f1']:.4f}"
)

print(
    f"ROC-AUC:   "
    f"{valid_metrics['roc_auc']:.4f}"
)

print("\nValidation Confusion Matrix:")

print(
    confusion_matrix(
        y_valid,
        y_valid_pred
    )
)

print("\nValidation Classification Report:")

print(
    classification_report(
        y_valid,
        y_valid_pred,
        zero_division=0
    )
)


# ============================================================
# Test
# ============================================================

y_test_pred, y_test_prob, test_metrics = (
    evaluate_model(
        model,
        X_test,
        y_test
    )
)

print("\n" + "=" * 65)
print("TEST METRICS")
print("=" * 65)

print(
    f"Accuracy:  "
    f"{test_metrics['accuracy']:.4f}"
)

print(
    f"Precision: "
    f"{test_metrics['precision']:.4f}"
)

print(
    f"Recall:    "
    f"{test_metrics['recall']:.4f}"
)

print(
    f"F1 Score:  "
    f"{test_metrics['f1']:.4f}"
)

print(
    f"ROC-AUC:   "
    f"{test_metrics['roc_auc']:.4f}"
)

print("\nTest Confusion Matrix:")

print(
    confusion_matrix(
        y_test,
        y_test_pred
    )
)

print("\nTest Classification Report:")

print(
    classification_report(
        y_test,
        y_test_pred,
        zero_division=0
    )
)


# ============================================================
# Save model
# ============================================================

MODEL_DIR.mkdir(
    parents=True,
    exist_ok=True
)

joblib.dump(
    model,
    MODEL_PATH
)

print(
    f"\nSaved Experiment 1 model to:\n"
    f"{MODEL_PATH}"
)


# ============================================================
# Save results
# ============================================================

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)

results = pd.DataFrame(
    [
        {
            "Experiment":
                "Experiment 1 - Q1 More Data",

            "Model":
                "Random Forest",

            "Training Period":
                "2026-01-01 to 2026-02-28",

            "Validation Period":
                "2026-03-01 to 2026-03-15",

            "Test Period":
                "2026-03-16 to 2026-03-31",

            "Feature Count":
                len(features),

            "Train Rows":
                len(X_train),

            "Validation Rows":
                len(X_valid),

            "Test Rows":
                len(X_test),

            "Train Delay Rate":
                train_delay_rate,

            "Validation Delay Rate":
                valid_delay_rate,

            "Test Delay Rate":
                test_delay_rate,

            "Validation Accuracy":
                valid_metrics["accuracy"],

            "Validation Precision":
                valid_metrics["precision"],

            "Validation Recall":
                valid_metrics["recall"],

            "Validation F1":
                valid_metrics["f1"],

            "Validation ROC-AUC":
                valid_metrics["roc_auc"],

            "Test Accuracy":
                test_metrics["accuracy"],

            "Test Precision":
                test_metrics["precision"],

            "Test Recall":
                test_metrics["recall"],

            "Test F1":
                test_metrics["f1"],

            "Test ROC-AUC":
                test_metrics["roc_auc"],
        }
    ]
)

results.to_csv(
    RESULTS_PATH,
    index=False
)

print(
    f"\nSaved Experiment 1 results to:\n"
    f"{RESULTS_PATH}"
)


# ============================================================
# Final summary
# ============================================================

print("\n" + "=" * 65)
print("EXPERIMENT 1 COMPLETE")
print("=" * 65)

print("\nExperiment variable:")
print("More historical training data")

print("\nHeld constant:")
print("- Random Forest")
print("- Same 11 features")
print("- n_estimators = 100")
print("- max_depth = 15")
print("- min_samples_split = 10")
print("- min_samples_leaf = 5")
print("- class_weight = balanced")
print("- random_state = 42")

print("\nFINAL TEST RESULTS")

print(
    f"Accuracy:  "
    f"{test_metrics['accuracy']:.4f}"
)

print(
    f"Precision: "
    f"{test_metrics['precision']:.4f}"
)

print(
    f"Recall:    "
    f"{test_metrics['recall']:.4f}"
)

print(
    f"F1 Score:  "
    f"{test_metrics['f1']:.4f}"
)

print(
    f"ROC-AUC:   "
    f"{test_metrics['roc_auc']:.4f}"
)

print(
    "\nExperiment 1 training complete."
)
