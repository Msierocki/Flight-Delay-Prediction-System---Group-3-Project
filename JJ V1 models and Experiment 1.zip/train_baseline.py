#used ai to add/clean up comments and add some additional validation checks.

import pandas as pd
import mlflow
import mlflow.sklearn
from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, classification_report
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

# =========================
# File paths
# =========================
PROJECT_ROOT = Path(__file__).resolve().parent
DATA_PATH = PROJECT_ROOT / "data" / "processed" / "flights_model_ready_v1.csv"

# =========================
# Load data
# =========================
print("Loading model-ready dataset...")
df = pd.read_csv(DATA_PATH)
print(f"Dataset shape: {df.shape}")
print("\nColumns:")
print(df.columns.tolist())


# =========================
# Basic cleanup
# =========================
if "FL_DATE" not in df.columns:
    raise ValueError("FL_DATE column is required for time-based splitting.")

if "TARGET_DELAYED" not in df.columns:
    raise ValueError("TARGET_DELAYED column is required as the target variable.")

df["FL_DATE"] = pd.to_datetime(df["FL_DATE"], errors="coerce")
df = df[df["FL_DATE"].notna()].copy()
df = df.sort_values("FL_DATE").reset_index(drop=True)

print("\nTarget distribution:")
print(df["TARGET_DELAYED"].value_counts(dropna=False))
print(f"Delay rate: {df['TARGET_DELAYED'].mean():.2%}")


# =========================
# Feature selection
# Combined strongest Version 1 features from the proposal and notebook
# =========================
feature_candidates = [
    "OP_CARRIER_FL_NUM",
    "ORIGIN",
    "ORIGIN_STATE_NM",
    "DEST",
    "DEST_STATE_NM",
    "CRS_DEP_TIME",
    "CRS_ARR_TIME",
    "CRS_ELAPSED_TIME",
    "MONTH",
    "DAY_OF_WEEK",
    "DAY",
    "DAY_OF_MONTH",
    "IS_WEEKEND",
    "CRS_DEP_HOUR",
    "CRS_DEP_MINUTE",
    "CRS_ARR_HOUR",
    "CRS_ARR_MINUTE",
    "DEP_HOUR",
    "ROUTE"
]

features = [col for col in feature_candidates if col in df.columns]
missing_feature_candidates = [col for col in feature_candidates if col not in df.columns]

print("\nUsing features:")
print(features)

if missing_feature_candidates:
    print("\nFeature candidates not found in dataset:")
    print(missing_feature_candidates)

if not features:
    raise ValueError("No modeling features were found in the dataset.")

X = df[features].copy()
y = df["TARGET_DELAYED"].astype(int).copy()


# =========================
# Time-based split
# 70% train, 15% validation, 15% test
# =========================
train_end = int(len(df) * 0.70)
valid_end = int(len(df) * 0.85)

X_train = X.iloc[:train_end].copy()
y_train = y.iloc[:train_end].copy()

X_valid = X.iloc[train_end:valid_end].copy()
y_valid = y.iloc[train_end:valid_end].copy()

X_test = X.iloc[valid_end:].copy()
y_test = y.iloc[valid_end:].copy()

print("\nTime-based split summary:")
print(f"Train rows: {len(X_train):,}")
print(f"Validation rows: {len(X_valid):,}")
print(f"Test rows: {len(X_test):,}")
print(f"Train date range: {df.iloc[:train_end]['FL_DATE'].min()} to {df.iloc[:train_end]['FL_DATE'].max()}")
print(f"Validation date range: {df.iloc[train_end:valid_end]['FL_DATE'].min()} to {df.iloc[train_end:valid_end]['FL_DATE'].max()}")
print(f"Test date range: {df.iloc[valid_end:]['FL_DATE'].min()} to {df.iloc[valid_end:]['FL_DATE'].max()}")


# =========================
# Identify numeric and categorical features
# =========================
numeric_features = X_train.select_dtypes(include=["number"]).columns.tolist()
categorical_features = [col for col in X_train.columns if col not in numeric_features]

print("\nNumeric features:")
print(numeric_features)
print("\nCategorical features:")
print(categorical_features)


# =========================
# Preprocessing pipelines
# =========================
numeric_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer(transformers=[
    ("num", numeric_transformer, numeric_features),
    ("cat", categorical_transformer, categorical_features)
])

# =========================
# MLflow experiment setup
# =========================
mlflow.set_experiment("Flight Delay Prediction")

# =========================
# Baseline model: Balanced Logistic Regression
# =========================
model = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("classifier", LogisticRegression(
        max_iter=2000,
        class_weight="balanced",
        random_state=42
    ))
])

print("\nTraining Logistic Regression baseline...")

print("\nTraining Logistic Regression baseline...")

with mlflow.start_run(run_name="Logistic Regression Baseline"):

    # =========================
    # Log model parameters
    # =========================
    mlflow.log_param("model_type", "LogisticRegression")
    mlflow.log_param("max_iter", 2000)
    mlflow.log_param("class_weight", "balanced")
    mlflow.log_param("random_state", 42)
    mlflow.log_param("train_rows", len(X_train))
    mlflow.log_param("validation_rows", len(X_valid))
    mlflow.log_param("test_rows", len(X_test))
    mlflow.log_param("num_features", len(features))

    # =========================
    # Train model
    # =========================
    model.fit(X_train, y_train)

    # =========================
    # Validation evaluation
    # =========================
    y_valid_pred = model.predict(X_valid)
    y_valid_prob = model.predict_proba(X_valid)[:, 1]

    valid_accuracy = accuracy_score(y_valid, y_valid_pred)
    valid_precision = precision_score(
        y_valid, y_valid_pred, zero_division=0
    )
    valid_recall = recall_score(
        y_valid, y_valid_pred, zero_division=0
    )
    valid_f1 = f1_score(
        y_valid, y_valid_pred, zero_division=0
    )
    valid_roc_auc = roc_auc_score(
        y_valid, y_valid_prob
    )

    # Log validation metrics to MLflow
    mlflow.log_metric("validation_accuracy", valid_accuracy)
    mlflow.log_metric("validation_precision", valid_precision)
    mlflow.log_metric("validation_recall", valid_recall)
    mlflow.log_metric("validation_f1", valid_f1)
    mlflow.log_metric("validation_roc_auc", valid_roc_auc)

    print("\n================ VALIDATION METRICS ================")
    print(f"Accuracy:  {valid_accuracy:.4f}")
    print(f"Precision: {valid_precision:.4f}")
    print(f"Recall:    {valid_recall:.4f}")
    print(f"F1 Score:  {valid_f1:.4f}")
    print(f"ROC-AUC:   {valid_roc_auc:.4f}")

    print("\nValidation Confusion Matrix:")
    print(confusion_matrix(y_valid, y_valid_pred))

    print("\nValidation Classification Report:")
    print(
        classification_report(
            y_valid,
            y_valid_pred,
            zero_division=0
        )
    )

    # =========================
    # Test evaluation
    # =========================
    y_test_pred = model.predict(X_test)
    y_test_prob = model.predict_proba(X_test)[:, 1]

    test_accuracy = accuracy_score(y_test, y_test_pred)
    test_precision = precision_score(
        y_test, y_test_pred, zero_division=0
    )
    test_recall = recall_score(
        y_test, y_test_pred, zero_division=0
    )
    test_f1 = f1_score(
        y_test, y_test_pred, zero_division=0
    )
    test_roc_auc = roc_auc_score(
        y_test, y_test_prob
    )

    # Log test metrics to MLflow
    mlflow.log_metric("test_accuracy", test_accuracy)
    mlflow.log_metric("test_precision", test_precision)
    mlflow.log_metric("test_recall", test_recall)
    mlflow.log_metric("test_f1", test_f1)
    mlflow.log_metric("test_roc_auc", test_roc_auc)

    print("\n==================== TEST METRICS ===================")
    print(f"Accuracy:  {test_accuracy:.4f}")
    print(f"Precision: {test_precision:.4f}")
    print(f"Recall:    {test_recall:.4f}")
    print(f"F1 Score:  {test_f1:.4f}")
    print(f"ROC-AUC:   {test_roc_auc:.4f}")

    print("\nTest Confusion Matrix:")
    print(confusion_matrix(y_test, y_test_pred))

    print("\nTest Classification Report:")
    print(
        classification_report(
            y_test,
            y_test_pred,
            zero_division=0
        )
    )

    # =========================
    # Log trained model
    # =========================
    mlflow.sklearn.log_model(
    sk_model=model,
    name="logistic_regression_model",
    skops_trusted_types=["numpy.dtype"]
)

    print("\nModel and metrics logged to MLflow.")

print("\nBaseline training complete.")