# ============================================================
# Experiment 1: Q1 2026 Data Preparation
#
# Combines January, February, and March 2026 flight data.
# Uses the same feature definitions as the January V1 baseline
# so Experiment 1 tests the effect of MORE DATA.
# ============================================================

import pandas as pd
import numpy as np
from pathlib import Path


# ============================================================
# Project paths
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

RAW_DATA_DIR = PROJECT_ROOT / "data" / "raw"
PROCESSED_DATA_DIR = PROJECT_ROOT / "data" / "processed"

CLEAN_FULL_PATH = (
    PROCESSED_DATA_DIR
    / "flights_clean_q1_2026.csv"
)

MODEL_READY_PATH = (
    PROCESSED_DATA_DIR
    / "flights_model_ready_q1_2026.csv"
)


# ============================================================
# Q1 source files
# ============================================================

Q1_FILES = [
    RAW_DATA_DIR / "flights_2026_01.csv",
    RAW_DATA_DIR / "flights_2026_02.csv",
    RAW_DATA_DIR / "flights_2026_03.csv",
]


# ============================================================
# Helper function
# ============================================================

def parse_hhmm(value):
    """
    Convert BTS HHMM scheduled time into hour and minute.

    Examples:
    730  -> 7, 30
    1735 -> 17, 35
    """

    if pd.isna(value):
        return pd.Series([np.nan, np.nan])

    try:
        value = int(float(value))
        hhmm = f"{value:04d}"

        hour = int(hhmm[:2])
        minute = int(hhmm[2:])

        # Some transportation datasets use 2400 for midnight.
        if hour == 24 and minute == 0:
            return pd.Series([0, 0])

        if hour > 23 or minute > 59:
            return pd.Series([np.nan, np.nan])

        return pd.Series([hour, minute])

    except (ValueError, TypeError):
        return pd.Series([np.nan, np.nan])


# ============================================================
# Start
# ============================================================

print("=" * 60)
print("EXPERIMENT 1 — Q1 2026 DATA PREPARATION")
print("=" * 60)


# ============================================================
# Check source files
# ============================================================

print("\nChecking Q1 source files...")

for file_path in Q1_FILES:

    if not file_path.exists():
        raise FileNotFoundError(
            f"\nRequired file not found:\n"
            f"{file_path}\n\n"
            f"Expected these files inside data/raw:\n"
            f"flights_2026_01.csv\n"
            f"flights_2026_02.csv\n"
            f"flights_2026_03.csv"
        )

    print(f"Found: {file_path.name}")


# ============================================================
# Load monthly files
# ============================================================

monthly_datasets = []
reference_columns = None

for file_path in Q1_FILES:

    print(f"\nLoading {file_path.name}...")

    month_df = pd.read_csv(
        file_path,
        low_memory=False
    )

    # Standardize column names.
    month_df.columns = [
        col.strip().upper()
        for col in month_df.columns
    ]

    print(f"Rows loaded: {len(month_df):,}")
    print(f"Columns loaded: {len(month_df.columns)}")

    # --------------------------------------------------------
    # Compare monthly schemas
    # --------------------------------------------------------

    current_columns = set(month_df.columns)

    if reference_columns is None:
        reference_columns = current_columns

    else:

        missing_columns = (
            reference_columns - current_columns
        )

        extra_columns = (
            current_columns - reference_columns
        )

        if missing_columns:
            print(
                f"WARNING: {file_path.name} "
                f"is missing columns:"
            )
            print(sorted(missing_columns))

        if extra_columns:
            print(
                f"NOTE: {file_path.name} "
                f"contains additional columns:"
            )
            print(sorted(extra_columns))

    # Keep the source file for auditing.
    month_df["SOURCE_FILE"] = file_path.name

    monthly_datasets.append(month_df)


# ============================================================
# Combine Q1 files
# ============================================================

print("\nCombining January, February, and March...")

df = pd.concat(
    monthly_datasets,
    ignore_index=True,
    sort=False
)

print(f"Combined raw rows: {len(df):,}")
print(f"Combined columns: {len(df.columns)}")


# ============================================================
# Validate required columns
# ============================================================

required_columns = [
    "FL_DATE",
    "OP_CARRIER_FL_NUM",
    "ORIGIN",
    "DEST",
    "CRS_DEP_TIME",
    "ARR_DEL15",
    "CANCELLED",
]

missing_required = [
    column
    for column in required_columns
    if column not in df.columns
]

if missing_required:
    raise ValueError(
        "Required columns are missing from the Q1 data: "
        f"{missing_required}"
    )


# ============================================================
# Remove duplicate rows
# ============================================================

rows_before_duplicates = len(df)

# SOURCE_FILE should not affect duplicate detection.
duplicate_check_df = df.drop(
    columns=["SOURCE_FILE"],
    errors="ignore"
)

duplicate_mask = duplicate_check_df.duplicated()

df = df.loc[
    ~duplicate_mask
].copy()

duplicates_removed = (
    rows_before_duplicates - len(df)
)

print(
    f"\nDuplicate rows removed: "
    f"{duplicates_removed:,}"
)


# ============================================================
# Parse flight dates
# ============================================================

df["FL_DATE"] = pd.to_datetime(
    df["FL_DATE"],
    errors="coerce"
)

invalid_dates = df["FL_DATE"].isna().sum()

print(
    f"Invalid/missing FL_DATE values: "
    f"{invalid_dates:,}"
)

df = df[
    df["FL_DATE"].notna()
].copy()


# ============================================================
# Check raw Q1 date coverage
# ============================================================

print("\nRaw Q1 date coverage:")

print(
    f"{df['FL_DATE'].min().date()} "
    f"through "
    f"{df['FL_DATE'].max().date()}"
)

print("\nRows by month before filtering:")

raw_month_counts = (
    df["FL_DATE"]
    .dt.to_period("M")
    .value_counts()
    .sort_index()
)

print(raw_month_counts)


# ============================================================
# Remove cancelled flights
# ============================================================

rows_before_cancelled = len(df)

df = df[
    df["CANCELLED"] != 1
].copy()

cancelled_removed = (
    rows_before_cancelled - len(df)
)

print(
    f"\nCancelled flights removed: "
    f"{cancelled_removed:,}"
)


# ============================================================
# Remove diverted flights
#
# Same rule as the January baseline.
# ============================================================

if "DIV_ARR_DELAY" in df.columns:

    diverted_mask = df["DIV_ARR_DELAY"].notna()

    diverted_removed = int(
        diverted_mask.sum()
    )

    df = df[
        ~diverted_mask
    ].copy()

    print(
        f"Diverted flights removed: "
        f"{diverted_removed:,}"
    )

else:

    print(
        "DIV_ARR_DELAY not found. "
        "No diverted-flight filter applied."
    )


# ============================================================
# Remove rows without target
# ============================================================

rows_before_target = len(df)

df = df[
    df["ARR_DEL15"].notna()
].copy()

missing_target_removed = (
    rows_before_target - len(df)
)

print(
    f"Rows with missing ARR_DEL15 removed: "
    f"{missing_target_removed:,}"
)


# ============================================================
# Keep valid binary target values
# ============================================================

df = df[
    df["ARR_DEL15"].isin([0, 1])
].copy()

df["TARGET_DELAYED"] = (
    df["ARR_DEL15"].astype(int)
)


# ============================================================
# Feature engineering
#
# These definitions intentionally match V1.
# ============================================================

df["MONTH"] = df["FL_DATE"].dt.month

df["DAY_OF_WEEK"] = (
    df["FL_DATE"].dt.dayofweek
)

df["DAY"] = df["FL_DATE"].dt.day

df["IS_WEEKEND"] = (
    df["DAY_OF_WEEK"]
    .isin([5, 6])
    .astype(int)
)


# ============================================================
# Scheduled departure features
# ============================================================

print(
    "\nCreating scheduled departure time features..."
)

df[
    [
        "CRS_DEP_HOUR",
        "CRS_DEP_MINUTE"
    ]
] = df["CRS_DEP_TIME"].apply(parse_hhmm)


# ============================================================
# Route feature
# ============================================================

df["ROUTE"] = (
    df["ORIGIN"].astype(str)
    + "_"
    + df["DEST"].astype(str)
)


# ============================================================
# Sort chronologically
# ============================================================

df = df.sort_values(
    "FL_DATE"
).reset_index(drop=True)


# ============================================================
# Q1 cleaning validation
# ============================================================

print("\n" + "=" * 60)
print("Q1 CLEANING VALIDATION")
print("=" * 60)

print(
    f"\nRows after cleaning: "
    f"{len(df):,}"
)

print(
    f"Date range: "
    f"{df['FL_DATE'].min().date()} "
    f"through "
    f"{df['FL_DATE'].max().date()}"
)


# ============================================================
# Monthly row counts
# ============================================================

print("\nClean rows by month:")

monthly_counts = (
    df["FL_DATE"]
    .dt.to_period("M")
    .value_counts()
    .sort_index()
)

print(monthly_counts)


# ============================================================
# Verify all three Q1 months exist
# ============================================================

expected_months = {
    "2026-01",
    "2026-02",
    "2026-03",
}

actual_months = set(
    df["FL_DATE"]
    .dt.to_period("M")
    .astype(str)
    .unique()
)

missing_months = (
    expected_months - actual_months
)

if missing_months:

    raise ValueError(
        "Expected Q1 months are missing "
        "after cleaning: "
        f"{sorted(missing_months)}"
    )


# ============================================================
# Target distribution
# ============================================================

print("\nTarget distribution:")

target_distribution = (
    df["TARGET_DELAYED"]
    .value_counts()
    .sort_index()
)

print(target_distribution)

print(
    f"\nOverall Q1 delay rate: "
    f"{df['TARGET_DELAYED'].mean():.2%}"
)


# ============================================================
# Delay rate by month
# ============================================================

print("\nDelay rate by month:")

monthly_delay_rate = (
    df.groupby(
        df["FL_DATE"].dt.to_period("M")
    )["TARGET_DELAYED"]
    .mean()
)

for month, rate in monthly_delay_rate.items():
    print(
        f"{month}: {rate:.2%}"
    )


# ============================================================
# Validate key model fields
# ============================================================

key_fields = [
    "FL_DATE",
    "OP_CARRIER_FL_NUM",
    "ORIGIN",
    "DEST",
    "CRS_DEP_TIME",
    "CRS_DEP_HOUR",
    "CRS_DEP_MINUTE",
    "MONTH",
    "DAY_OF_WEEK",
    "DAY",
    "IS_WEEKEND",
    "ROUTE",
    "TARGET_DELAYED",
]

print(
    "\nMissing values in key model fields:"
)

print(
    df[key_fields]
    .isna()
    .sum()
)


# ============================================================
# Save full cleaned Q1 dataset
# ============================================================

PROCESSED_DATA_DIR.mkdir(
    parents=True,
    exist_ok=True
)

df.to_csv(
    CLEAN_FULL_PATH,
    index=False
)

print(
    f"\nSaved clean Q1 dataset to:\n"
    f"{CLEAN_FULL_PATH}"
)


# ============================================================
# Create model-ready Q1 dataset
#
# Experiment 1 uses the SAME 11 features as V1.
# ============================================================

model_columns = [
    "FL_DATE",
    "OP_CARRIER_FL_NUM",
    "ORIGIN",
    "DEST",
    "CRS_DEP_TIME",
    "MONTH",
    "DAY_OF_WEEK",
    "DAY",
    "IS_WEEKEND",
    "CRS_DEP_HOUR",
    "CRS_DEP_MINUTE",
    "ROUTE",
    "TARGET_DELAYED",
]


missing_model_columns = [
    column
    for column in model_columns
    if column not in df.columns
]

if missing_model_columns:

    raise ValueError(
        "Required model columns are missing: "
        f"{missing_model_columns}"
    )


model_df = df[
    model_columns
].copy()


# ============================================================
# Final chronological sort
# ============================================================

model_df = model_df.sort_values(
    "FL_DATE"
).reset_index(drop=True)


# ============================================================
# Save model-ready Q1 dataset
# ============================================================

model_df.to_csv(
    MODEL_READY_PATH,
    index=False
)

print(
    f"\nSaved model-ready Q1 dataset to:\n"
    f"{MODEL_READY_PATH}"
)


# ============================================================
# Experiment summary
# ============================================================

print("\n" + "=" * 60)
print("EXPERIMENT 1 DATASET SUMMARY")
print("=" * 60)

print(
    f"\nTotal model-ready rows: "
    f"{len(model_df):,}"
)

print(
    f"Date range: "
    f"{model_df['FL_DATE'].min().date()} "
    f"through "
    f"{model_df['FL_DATE'].max().date()}"
)

print(
    f"Overall delay rate: "
    f"{model_df['TARGET_DELAYED'].mean():.2%}"
)


feature_columns = [
    column
    for column in model_columns
    if column not in [
        "FL_DATE",
        "TARGET_DELAYED"
    ]
]

print("\nModel features:")

for feature in feature_columns:
    print(f"- {feature}")

print(
    f"\nNumber of model features: "
    f"{len(feature_columns)}"
)

print("\nExperiment variable:")

print(
    "More historical data "
    "(Q1 2026 vs. January 2026 baseline)"
)

print("\nFeature set:")

print(
    "Held constant relative to V1."
)

print(
    "\nQ1 data preparation complete."
)
