from pathlib import Path

import pandas as pd
import mlflow


# ============================================================
# Paths
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

MLFLOW_DB_PATH = PROJECT_ROOT / "mlflow.db"

MODEL_PATH = (
    PROJECT_ROOT
    / "models"
    / "experiment1_q1_random_forest.joblib"
)

RESULTS_PATH = (
    PROJECT_ROOT
    / "results"
    / "experiment1_q1_random_forest_metrics.csv"
)


# ============================================================
# Check required files
# ============================================================

if not MODEL_PATH.exists():
    raise FileNotFoundError(
        f"Model not found:\n{MODEL_PATH}"
    )

if not RESULTS_PATH.exists():
    raise FileNotFoundError(
        f"Results file not found:\n{RESULTS_PATH}"
    )


# ============================================================
# Connect to existing MLflow database
# ============================================================

mlflow.set_tracking_uri(
    f"sqlite:///{MLFLOW_DB_PATH}"
)

mlflow.set_experiment(
    "Flight Delay Prediction"
)


# ============================================================
# Load saved Experiment 1 results
# ============================================================

results_df = pd.read_csv(
    RESULTS_PATH
)

if len(results_df) != 1:
    raise ValueError(
        "Expected exactly one row in the Experiment 1 results file."
    )

results = results_df.iloc[0]


# ============================================================
# Start Experiment 1 MLflow run
# ============================================================

with mlflow.start_run(
    run_name="Experiment 1 - Q1 More Data - Random Forest"
) as run:

    # --------------------------------------------------------
    # Experiment description
    # --------------------------------------------------------

    mlflow.set_tag(
        "experiment",
        "Experiment 1"
    )

    mlflow.set_tag(
        "experiment_goal",
        "Test effect of more historical training data"
    )

    mlflow.set_tag(
        "model_family",
        "Random Forest"
    )

    mlflow.set_tag(
        "status",
        "completed"
    )


    # --------------------------------------------------------
    # Parameters
    # --------------------------------------------------------

    mlflow.log_param(
        "experiment_variable",
        "more_historical_training_data"
    )

    mlflow.log_param(
        "training_period",
        "2026-01-01_to_2026-02-28"
    )

    mlflow.log_param(
        "validation_period",
        "2026-03-01_to_2026-03-15"
    )

    mlflow.log_param(
        "test_period",
        "2026-03-16_to_2026-03-31"
    )

    mlflow.log_param(
        "feature_count",
        11
    )

    mlflow.log_param(
        "n_estimators",
        100
    )

    mlflow.log_param(
        "max_depth",
        15
    )

    mlflow.log_param(
        "min_samples_split",
        10
    )

    mlflow.log_param(
        "min_samples_leaf",
        5
    )

    mlflow.log_param(
        "class_weight",
        "balanced"
    )

    mlflow.log_param(
        "random_state",
        42
    )

    mlflow.log_param(
        "train_rows",
        int(results["Train Rows"])
    )

    mlflow.log_param(
        "validation_rows",
        int(results["Validation Rows"])
    )

    mlflow.log_param(
        "test_rows",
        int(results["Test Rows"])
    )


    # --------------------------------------------------------
    # Validation metrics
    # --------------------------------------------------------

    mlflow.log_metric(
        "validation_accuracy",
        float(results["Validation Accuracy"])
    )

    mlflow.log_metric(
        "validation_precision",
        float(results["Validation Precision"])
    )

    mlflow.log_metric(
        "validation_recall",
        float(results["Validation Recall"])
    )

    mlflow.log_metric(
        "validation_f1",
        float(results["Validation F1"])
    )

    mlflow.log_metric(
        "validation_roc_auc",
        float(results["Validation ROC-AUC"])
    )


    # --------------------------------------------------------
    # Test metrics
    # --------------------------------------------------------

    mlflow.log_metric(
        "test_accuracy",
        float(results["Test Accuracy"])
    )

    mlflow.log_metric(
        "test_precision",
        float(results["Test Precision"])
    )

    mlflow.log_metric(
        "test_recall",
        float(results["Test Recall"])
    )

    mlflow.log_metric(
        "test_f1",
        float(results["Test F1"])
    )

    mlflow.log_metric(
        "test_roc_auc",
        float(results["Test ROC-AUC"])
    )


    # --------------------------------------------------------
    # Delay-rate metrics
    # --------------------------------------------------------

    mlflow.log_metric(
        "train_delay_rate",
        float(results["Train Delay Rate"])
    )

    mlflow.log_metric(
        "validation_delay_rate",
        float(results["Validation Delay Rate"])
    )

    mlflow.log_metric(
        "test_delay_rate",
        float(results["Test Delay Rate"])
    )


    # --------------------------------------------------------
    # Artifacts
    #
    # Log the existing joblib model as an artifact instead of
    # using mlflow.sklearn.log_model. This avoids the skops
    # trusted-type issue encountered earlier with RandomForest.
    # --------------------------------------------------------

    mlflow.log_artifact(
        str(MODEL_PATH),
        artifact_path="model"
    )

    mlflow.log_artifact(
        str(RESULTS_PATH),
        artifact_path="results"
    )


    # --------------------------------------------------------
    # Finish
    # --------------------------------------------------------

    print("=" * 65)
    print("EXPERIMENT 1 LOGGED TO MLFLOW")
    print("=" * 65)

    print(f"\nRun ID: {run.info.run_id}")
    print(f"Experiment: Flight Delay Prediction")
    print(f"Run name: Experiment 1 - Q1 More Data - Random Forest")

    print("\nTest metrics logged:")
    print(
        f"Accuracy:  "
        f"{float(results['Test Accuracy']):.4f}"
    )
    print(
        f"Precision: "
        f"{float(results['Test Precision']):.4f}"
    )
    print(
        f"Recall:    "
        f"{float(results['Test Recall']):.4f}"
    )
    print(
        f"F1 Score:  "
        f"{float(results['Test F1']):.4f}"
    )
    print(
        f"ROC-AUC:   "
        f"{float(results['Test ROC-AUC']):.4f}"
    )

    print("\nArtifacts logged:")
    print(f"- {MODEL_PATH.name}")
    print(f"- {RESULTS_PATH.name}")

print("\nDone.")
