import pandas as pd
import joblib

from pathlib import Path


# ============================================================
# Project paths
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

MODEL_PATH = (
    PROJECT_ROOT
    / "models"
    / "v1_random_forest.joblib"
)


# ============================================================
# Helper function
# ============================================================

def parse_hhmm(value):
    """
    Convert HHMM time into hour and minute.

    Examples:
    730  -> 7:30 AM
    1735 -> 5:35 PM
    """

    try:
        value = int(value)
    except ValueError:
        raise ValueError(
            "Departure time must be numeric, such as 730 or 1735."
        )

    hhmm = f"{value:04d}"

    hour = int(hhmm[:2])
    minute = int(hhmm[2:])

    if hour == 24 and minute == 0:
        hour = 0

    if hour > 23 or minute > 59:
        raise ValueError(
            "Time must be a valid HHMM value, "
            "such as 730, 0930, or 1745."
        )

    return hour, minute


# ============================================================
# Check model exists
# ============================================================

if not MODEL_PATH.exists():
    raise FileNotFoundError(
        f"Model not found at:\n{MODEL_PATH}\n\n"
        "Run train_random_forest.py first."
    )


# ============================================================
# Load trained Random Forest
# ============================================================

print("Loading trained Random Forest model...")

model = joblib.load(MODEL_PATH)

print("Model loaded successfully.\n")


# ============================================================
# Collect flight information
# ============================================================

print("Enter flight information for prediction.\n")

flight_date_input = input(
    "Flight date (YYYY-MM-DD): "
).strip()

flight_num_input = input(
    "Flight number (example: 1274): "
).strip()

origin_input = input(
    "Origin airport code (example: JFK): "
).strip().upper()

dest_input = input(
    "Destination airport code (example: LAX): "
).strip().upper()

departure_time_input = input(
    "Scheduled departure time in HHMM format "
    "(example: 730 or 1735): "
).strip()


# ============================================================
# Validate inputs
# ============================================================

try:
    flight_date = pd.to_datetime(
        flight_date_input,
        format="%Y-%m-%d",
    )
except ValueError:
    raise ValueError(
        "Flight date must use YYYY-MM-DD format."
    )


try:
    flight_number = int(flight_num_input)
except ValueError:
    raise ValueError(
        "Flight number must be numeric."
    )


departure_hour, departure_minute = parse_hhmm(
    departure_time_input
)


if len(origin_input) != 3:
    raise ValueError(
        "Origin airport should be a 3-letter airport code."
    )


if len(dest_input) != 3:
    raise ValueError(
        "Destination airport should be a 3-letter airport code."
    )


# ============================================================
# Create date features
#
# IMPORTANT:
# data_prep.py created DAY_OF_WEEK using pandas:
#
# Monday = 0
# Tuesday = 1
# ...
# Sunday = 6
#
# Prediction must use the exact same definition.
# ============================================================

day_of_week = flight_date.dayofweek

is_weekend = int(
    day_of_week in [5, 6]
)


# ============================================================
# Build route
# ============================================================

route = f"{origin_input}_{dest_input}"


# ============================================================
# Create model input
#
# These are the exact 11 features used by the trained
# Random Forest model.
# ============================================================

input_df = pd.DataFrame(
    [
        {
            "OP_CARRIER_FL_NUM": flight_number,
            "ORIGIN": origin_input,
            "DEST": dest_input,
            "CRS_DEP_TIME": int(departure_time_input),
            "MONTH": flight_date.month,
            "DAY_OF_WEEK": day_of_week,
            "DAY": flight_date.day,
            "IS_WEEKEND": is_weekend,
            "CRS_DEP_HOUR": departure_hour,
            "CRS_DEP_MINUTE": departure_minute,
            "ROUTE": route,
        }
    ]
)


# ============================================================
# Display flight being evaluated
# ============================================================

print("\nFlight information:")

print(f"Date: {flight_date.date()}")
print(f"Flight number: {flight_number}")
print(f"Route: {origin_input} -> {dest_input}")

print(
    f"Scheduled departure: "
    f"{departure_hour:02d}:{departure_minute:02d}"
)


# ============================================================
# Make prediction
# ============================================================

prediction = model.predict(input_df)[0]

probability_delay = model.predict_proba(
    input_df
)[0, 1]


# ============================================================
# Risk category
#
# These categories are descriptive only.
# The classifier itself still uses its learned decision rule.
# ============================================================

if probability_delay >= 0.70:
    risk_level = "High"

elif probability_delay >= 0.40:
    risk_level = "Moderate"

else:
    risk_level = "Low"


# ============================================================
# Output
# ============================================================

print(
    "\n================ FLIGHT DELAY PREDICTION ================"
)

print(
    f"Predicted probability of delay: "
    f"{probability_delay:.2%}"
)

print(
    f"Risk level: {risk_level}"
)

print(
    f"Predicted class: "
    f"{'Delayed' if prediction == 1 else 'Not Delayed'}"
)

print(
    "========================================================="
)


print("\nInterpretation:")

print(
    "- The probability is based on patterns learned "
    "from the January 2026 training data."
)

print(
    "- The prediction is an estimate and should not "
    "be interpreted as a guarantee."
)

print(
    "- The model uses scheduled/pre-departure information "
    "rather than information that becomes known after "
    "the flight departs."
)