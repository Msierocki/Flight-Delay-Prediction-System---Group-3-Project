import pandas as pd
import joblib
import mlflow
import mlflow.sklearn

from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder


# ============================================================
# File paths
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

DATA_PATH = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "flights_model_ready_v1.csv"
)

MODEL_DIR = PROJECT_ROOT / "models"
MODEL_PATH = MODEL_DIR / "v1_random_forest.joblib"


# ============================================================
# Load data
# ============================================================

print("Loading model-ready dataset...")

df = pd.read_csv(DATA_PATH)

print(f"Dataset shape: {df.shape}")


# ============================================================
# Validate data
# ============================================================

if "FL_DATE" not in df.columns:
    raise ValueError("FL_DATE column is required.")

if "TARGET_DELAYED" not in df.columns:
    raise ValueError("TARGET_DELAYED column is required.")

df["FL_DATE"] = pd.to_datetime(
    df["FL_DATE"],
    errors="coerce",
)

df = df[df["FL_DATE"].notna()].copy()

df = df.sort_values("FL_DATE").reset_index(drop=True)

print("\nTarget distribution:")
print(df["TARGET_DELAYED"].value_counts())

print(
    f"Delay rate: "
    f"{df['TARGET_DELAYED'].mean():.2%}"
)


# ============================================================
# Feature selection
# ============================================================

feature_candidates = [
    "OP_CARRIER_FL_NUM",
    "ORIGIN",
    "ORIGIN_STATE_NM",
    "DEST",
    "DEST_STATE_NM",
    "CRS_DEP_TIME",
    "CRS_ARR_TIME",
    "CRS_ELAPSED_TIME",
    "MONTH",
    "DAY_OF_WEEK",
    "DAY",
    "DAY_OF_MONTH",
    "IS_WEEKEND",
    "CRS_DEP_HOUR",
    "CRS_DEP_MINUTE",
    "CRS_ARR_HOUR",
    "CRS_ARR_MINUTE",
    "DEP_HOUR",
    "ROUTE",
]

features = [
    col for col in feature_candidates
    if col in df.columns
]

print("\nUsing features:")
print(features)

if not features:
    raise ValueError("No modeling features found.")

X = df[features].copy()
y = df["TARGET_DELAYED"].astype(int).copy()


# ============================================================
# Time-based 70/15/15 split
# ============================================================

train_end = int(len(df) * 0.70)
valid_end = int(len(df) * 0.85)

X_train = X.iloc[:train_end].copy()
y_train = y.iloc[:train_end].copy()

X_valid = X.iloc[train_end:valid_end].copy()
y_valid = y.iloc[train_end:valid_end].copy()

X_test = X.iloc[valid_end:].copy()
y_test = y.iloc[valid_end:].copy()

print("\nTime-based split:")
print(f"Train:      {len(X_train):,}")
print(f"Validation: {len(X_valid):,}")
print(f"Test:       {len(X_test):,}")


# ============================================================
# Preprocessing
# ============================================================

numeric_features = (
    X_train
    .select_dtypes(include=["number"])
    .columns
    .tolist()
)

categorical_features = [
    col for col in X_train.columns
    if col not in numeric_features
]

print("\nNumeric features:")
print(numeric_features)

print("\nCategorical features:")
print(categorical_features)


numeric_transformer = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(strategy="median"),
        )
    ]
)

categorical_transformer = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(strategy="most_frequent"),
        ),
        (
            "onehot",
            OneHotEncoder(handle_unknown="ignore"),
        ),
    ]
)

preprocessor = ColumnTransformer(
    transformers=[
        (
            "num",
            numeric_transformer,
            numeric_features,
        ),
        (
            "cat",
            categorical_transformer,
            categorical_features,
        ),
    ]
)


# ============================================================
# Random Forest
# ============================================================

model = Pipeline(
    steps=[
        (
            "preprocessor",
            preprocessor,
        ),
        (
            "classifier",
            RandomForestClassifier(
                n_estimators=100,
                max_depth=15,
                min_samples_split=10,
                min_samples_leaf=5,
                class_weight="balanced",
                random_state=42,
                n_jobs=-1,
            ),
        ),
    ]
)


# ============================================================
# MLflow
# ============================================================

mlflow.set_experiment("Flight Delay Prediction")

print("\nTraining Random Forest...")


with mlflow.start_run(run_name="Random Forest v1"):

    # Log parameters

    mlflow.log_params(
        {
            "model_type": "RandomForestClassifier",
            "n_estimators": 100,
            "max_depth": 15,
            "min_samples_split": 10,
            "min_samples_leaf": 5,
            "class_weight": "balanced",
            "random_state": 42,
            "train_rows": len(X_train),
            "validation_rows": len(X_valid),
            "test_rows": len(X_test),
            "num_features": len(features),
        }
    )

    # Train

    model.fit(X_train, y_train)

    print("\nTraining complete.")

    # Save local model

    MODEL_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    joblib.dump(
        model,
        MODEL_PATH,
    )

    print(f"Saved model to: {MODEL_PATH}")

    mlflow.log_artifact(
        str(MODEL_PATH),
        artifact_path="joblib_model",
    )

    # ========================================================
    # Validation
    # ========================================================

    y_valid_pred = model.predict(X_valid)

    y_valid_prob = model.predict_proba(
        X_valid
    )[:, 1]

    validation_metrics = {
        "validation_accuracy": accuracy_score(
            y_valid,
            y_valid_pred,
        ),
        "validation_precision": precision_score(
            y_valid,
            y_valid_pred,
            zero_division=0,
        ),
        "validation_recall": recall_score(
            y_valid,
            y_valid_pred,
            zero_division=0,
        ),
        "validation_f1": f1_score(
            y_valid,
            y_valid_pred,
            zero_division=0,
        ),
        "validation_roc_auc": roc_auc_score(
            y_valid,
            y_valid_prob,
        ),
    }

    mlflow.log_metrics(validation_metrics)

    print("\n================ VALIDATION METRICS ================")

    print(
        f"Accuracy:  "
        f"{validation_metrics['validation_accuracy']:.4f}"
    )

    print(
        f"Precision: "
        f"{validation_metrics['validation_precision']:.4f}"
    )

    print(
        f"Recall:    "
        f"{validation_metrics['validation_recall']:.4f}"
    )

    print(
        f"F1 Score:  "
        f"{validation_metrics['validation_f1']:.4f}"
    )

    print(
        f"ROC-AUC:   "
        f"{validation_metrics['validation_roc_auc']:.4f}"
    )

    print("\nValidation Confusion Matrix:")

    print(
        confusion_matrix(
            y_valid,
            y_valid_pred,
        )
    )

    print("\nValidation Classification Report:")

    print(
        classification_report(
            y_valid,
            y_valid_pred,
            zero_division=0,
        )
    )

    # ========================================================
    # Test
    # ========================================================

    y_test_pred = model.predict(X_test)

    y_test_prob = model.predict_proba(
        X_test
    )[:, 1]

    test_metrics = {
        "test_accuracy": accuracy_score(
            y_test,
            y_test_pred,
        ),
        "test_precision": precision_score(
            y_test,
            y_test_pred,
            zero_division=0,
        ),
        "test_recall": recall_score(
            y_test,
            y_test_pred,
            zero_division=0,
        ),
        "test_f1": f1_score(
            y_test,
            y_test_pred,
            zero_division=0,
        ),
        "test_roc_auc": roc_auc_score(
            y_test,
            y_test_prob,
        ),
    }

    mlflow.log_metrics(test_metrics)

    print("\n==================== TEST METRICS ===================")

    print(
        f"Accuracy:  "
        f"{test_metrics['test_accuracy']:.4f}"
    )

    print(
        f"Precision: "
        f"{test_metrics['test_precision']:.4f}"
    )

    print(
        f"Recall:    "
        f"{test_metrics['test_recall']:.4f}"
    )

    print(
        f"F1 Score:  "
        f"{test_metrics['test_f1']:.4f}"
    )

    print(
        f"ROC-AUC:   "
        f"{test_metrics['test_roc_auc']:.4f}"
    )

    print("\nTest Confusion Matrix:")

    print(
        confusion_matrix(
            y_test,
            y_test_pred,
        )
    )

    print("\nTest Classification Report:")

    print(
        classification_report(
            y_test,
            y_test_pred,
            zero_division=0,
        )
    )

    # ========================================================
    # MLflow model artifact
    # ========================================================

    mlflow.sklearn.log_model(
        sk_model=model,
        name="random_forest_model",
        skops_trusted_types=[
            "numpy.dtype",
            "sklearn.tree._tree.Tree",
        ],
    )

    print(
        "\nRandom Forest model and metrics "
        "logged successfully to MLflow."
    )


print("\nRandom Forest training complete.")

